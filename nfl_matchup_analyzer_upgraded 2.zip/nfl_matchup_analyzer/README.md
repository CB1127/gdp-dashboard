# NFL Matchup Analyzer — upgraded edition

## Included features
- Search for any player in the selected season
- Full-season, last-5-game, and last-3-game averages
- Passing, rushing, and receiving yards
- Carries, targets, receptions, completions, attempts, interceptions, and passing/rushing/receiving TD averages
- Automatically finds the player's next scheduled regular-season opponent
- Opponent overall passing/rushing/receiving yards allowed per game
- Position-specific defensive matchup views:
  - QB passing yards allowed to QBs
  - RB rushing and receiving yards allowed to RBs
  - WR receiving yards allowed to WRs
  - TE receiving yards allowed to TEs
- League defensive rankings by position
- Player home/away splits
- Player game log
- Injury scenario adjustment (healthy, questionable, doubtful, out, or custom percentage)
- Transparent blended yardage projection for the player's position

## Data-source limitation
This project uses public weekly data releases from **nflverse**, not a direct Pro Football Reference scraper. Pro Football Reference does not provide a public stats API and may restrict automated scraping. The app does not bypass those restrictions. Injury data is best-effort and optional; always verify the latest official injury report.

## Run locally
1. Install Python 3.10+.
2. Extract this ZIP.
3. In Terminal/Command Prompt, enter the project folder.
4. Run:

   ```bash
   pip install -r requirements.txt
   streamlit run app.py
   ```

5. Open the local URL printed by Streamlit.

## Publish as an iPhone-friendly website
1. Create/sign in to GitHub.
2. Create a public repository.
3. Upload `app.py` and `requirements.txt`.
4. Open https://share.streamlit.io/ and sign in with GitHub.
5. Create a new app, choose the repository, and set main file to `app.py`.
6. Deploy.
7. Open the resulting URL in iPhone Safari → Share → Add to Home Screen.

## Notes
- The default selected season is 2026. The season can be changed in the sidebar.
- If the current-season data release has not yet been published or the upstream schema changes, the app will show a data-loading error instead of fabricating results.
- The defensive positional model aggregates opponent player yardage by game and position. It is a useful directional comparison, not an official NFL defensive ranking.
- Injury percentages are illustrative scenario adjustments and not medical advice or an official availability forecast.
